(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_f83845._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_f83845._.js",
  "chunks": [
    "static/chunks/[root of the server]__b94e07._.css",
    "static/chunks/_c26468._.js"
  ],
  "source": "dynamic"
});
