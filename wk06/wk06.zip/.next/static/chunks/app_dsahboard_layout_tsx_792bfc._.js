(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dsahboard_layout_tsx_792bfc._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dsahboard_layout_tsx_792bfc._.js",
  "chunks": [
    "static/chunks/_6444ff._.js"
  ],
  "source": "dynamic"
});
