(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/pages__error_5771e1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/pages__error_5771e1._.js",
  "chunks": [
    "static/chunks/[root of the server]__1e1522._.js",
    "static/chunks/545c3_react-dom_1c85ba._.js",
    "static/chunks/node_modules__pnpm_ca0bcc._.js",
    "static/chunks/[root of the server]__2e1cf5._.js"
  ],
  "source": "entry"
});
