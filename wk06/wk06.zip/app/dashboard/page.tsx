export default function Page() {
    return (
        <p>Dash Page</p>
    )
}